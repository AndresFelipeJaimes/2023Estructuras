/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package retocolores;

/**
 *
 * @author cisco
 */
public class Rosa {
    // Atributos
    private String color;
    private int cantidadPetals;
    private boolean tieneEspinas;
    private String aroma;

    // Constructor
    public Rosa(String color, int cantidadPetals, boolean tieneEspinas, String aroma) {
        this.color = color;
        this.cantidadPetals = cantidadPetals;
        this.tieneEspinas = tieneEspinas;
        this.aroma = aroma;
    }

    // Métodos
    public void florecer() {
        System.out.println("La rosa está floreciendo.");
    }

    public void marchitar() {
        System.out.println("La rosa se está marchitando.");
    }
    
    public void perfumar() {
        System.out.println("La rosa está perfumando.");
    }

    // Getters y setters
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getCantidadPetals() {
        return cantidadPetals;
    }

    public void setCantidadPetals(int cantidadPetals) {
        this.cantidadPetals = cantidadPetals;
    }

    public boolean isTieneEspinas() {
        return tieneEspinas;
    }

    public void setTieneEspinas(boolean tieneEspinas) {
        this.tieneEspinas = tieneEspinas;
    }
    
    public String getAroma() {
        return aroma;
    }

    public void setAroma(String aroma) {
        this.aroma = aroma;
    }
}
