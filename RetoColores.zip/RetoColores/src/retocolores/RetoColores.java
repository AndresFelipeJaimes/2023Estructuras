/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package retocolores;

/**
 *
 * @author cisco
 */
public class RetoColores {
    public static void main(String[] args) {
        Rosa miRosa = new Rosa("Rojo", 10, true, "Agradable");
        
        System.out.println("Mi rosa es de color " + miRosa.getColor() + " y tiene " +
            miRosa.getCantidadPetals() + " pétalos.");
        
        miRosa.florecer();
        
        if (miRosa.isTieneEspinas()) {
            System.out.println("Mi rosa tiene espinas.");
        } else {
            System.out.println("Mi rosa no tiene espinas.");
        }
        
        System.out.println("El aroma de mi rosa es " + miRosa.getAroma());
        System.out.println("El color de mi rosa es " + miRosa.getColor());
    }
}
